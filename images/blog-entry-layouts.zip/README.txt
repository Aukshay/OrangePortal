A Pen created at CodePen.io. You can find this one at http://codepen.io/russbeye/pen/MYeroq.

 I've been procrastinating like a fiend lately, so I came up with any idea... One Design, One Week. Every week I will post a new design, so keep a look out!