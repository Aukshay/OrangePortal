/**
 * I am currently refactoring the CSS on this one, but I wanted
 * to quickly get the design hammered out. Also, I promised my
 * wife I wouldn't obsess over it.
 *
 * First part of my One Design One Week challenge
 *
 * Changelog 
 *    20 Dec 2014: Initial... Commit?
**/